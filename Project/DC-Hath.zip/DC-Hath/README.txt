# Digital-Communication

This is part 1 of digital communication project. 

The file "part 1 solution.png" is the solution generated already. 

If you want to generate the result again. Please run "part1_generator.m" directly. Please make sure all file are in the same direction.

