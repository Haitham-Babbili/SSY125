Convolution code simulation



PRELIMINARY PROJECT TIMELINE

Week 2
	- Read description
	- Meet group


Week 3
	- Simulated transmission


week 4
	- Read up on Viterbi
	- Think about implementation


Week 5
	- Simulate coded tx (part I)

Week 6
	- Part II

Week 7
	- Report writing

Final report: https://drive.google.com/file/d/0BwLsAQp-mZwJTFVGOVJaVU1GdEU/view?usp=sharing
